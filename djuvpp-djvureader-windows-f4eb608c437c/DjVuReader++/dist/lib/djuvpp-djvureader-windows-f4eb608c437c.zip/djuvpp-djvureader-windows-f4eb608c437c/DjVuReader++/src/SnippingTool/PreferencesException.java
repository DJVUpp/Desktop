package SnippingTool;
public class PreferencesException extends Exception {

    private static final long serialVersionUID = -4976383656388815952L;

    public PreferencesException(String msg) {
        super(msg);
    }
}