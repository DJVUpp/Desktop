package SnippingTool;

public class Provider { 
	/**
	 * http://stppl.us
	 */
	public static final int STPP = 1;
	
	/**
	 * http://imgur.com
	 */
	public static final int IMGUR = 0;
}