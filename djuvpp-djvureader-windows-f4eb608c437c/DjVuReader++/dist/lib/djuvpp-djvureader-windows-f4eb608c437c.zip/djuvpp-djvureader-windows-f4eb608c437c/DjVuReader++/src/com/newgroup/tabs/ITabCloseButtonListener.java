package com.newgroup.tabs;

import javax.swing.JTabbedPane;

public interface ITabCloseButtonListener
{
	public void tabCloseButtonPressed( JTabbedPane tabbedPane , int tabIndex );
}
