/*
Copyright 2012 James Edwards

This file is part of Jhrome.

Jhrome is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Jhrome is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with Jhrome.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.newgroup.tabs;

import java.awt.Component;
import java.awt.FlowLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * The default implementation of {@link ITabFactory}.
 * 
 * @author andy.edwards
 */
public class TestTabFactory implements ITabFactory
{
	private static int	tabCounter	= 1;
	
	public Tab createTab( )
	{
		return new Tab( );
	}
	
	@Override
	public Tab createTabWithContent( )
	{
		String title = "Tab " + ( tabCounter++ );
		Tab tab = new Tab( title , createTabContent( title ) );
		return tab;
	}
	
	private static Component createTabContent( String title )
	{
		JPanel content = new JPanel( );
		content.setOpaque( false );
		content.setLayout( new FlowLayout( ) );
		JLabel contentLabel = new JLabel( title );
		contentLabel.setFont( contentLabel.getFont( ).deriveFont( 72f ) );
		content.add( contentLabel );
		return content;
	}
}
