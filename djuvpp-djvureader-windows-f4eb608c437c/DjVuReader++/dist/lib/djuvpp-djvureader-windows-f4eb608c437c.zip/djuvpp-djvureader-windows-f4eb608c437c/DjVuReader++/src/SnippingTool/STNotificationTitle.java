package SnippingTool;

public enum STNotificationTitle
{
    NONE, TITLE_0, TITLE_1, TITLE_2, TITLE_3
}
